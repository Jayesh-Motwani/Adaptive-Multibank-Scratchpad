# Viva notes: concise oral answers

**What is a scratchpad?** A software- or controller-managed local memory for
explicitly placed data. A cache fills according to address tags and a
replacement policy; this project uses known tile IDs and bank states.

**Why does memory matter for a MAC accelerator?** Fast arithmetic cannot
execute when operands have not arrived. The testbench counts MAC idle clocks.

**What are tiling and reuse?** Divide a larger computation into pieces that
fit locally; reuse loaded values before replacing them. Our tile has four
activation/weight pairs in the main experiment.

**Why does one bank stall?** Loading and reading the same bank are serialized
by the policy, giving 640 cycles at fixed 8/8 for 32 tiles.

**What is ping-pong buffering?** Two banks alternate: one computes while the
other loads. It reduced that case to 361 cycles.

**Why can two banks still stall?** A latency burst can fill or occupy both
slots while the MAC waits for another completed tile.

**What does the fixed four-bank baseline do?** It uses round-robin searches
of EMPTY and READY banks and always permits all four banks to accept tiles.

**What is new in this project?** A lightweight runtime limit on the number of
banks eligible for new allocation. It changes among two, three, and four
using observed MAC starvation. Multi-bank memory and double buffering are
not claimed as new.

**How does hysteresis work?** Every 32 clocks, eight or more no-READY stall
events raise the limit one step; two or fewer lower it one step. Intermediate
counts keep the mode. The RTL uses integer comparisons, not division.

**What happens when the limit falls while bank 3 has a tile?** The bank is
no longer eligible for a new tile, but its READY or COMPUTING tile remains
valid and can finish. Dispatch searches all four banks.

**Why four physical banks?** Four provides a fixed deep baseline and enough
headroom to demonstrate 2/3/4 runtime modes. Under the tested variable 32-
tile case, benefits saturated at three; six and eight did not improve time.

**What happens when memory is slower?** The single load interface can become
the bottleneck, so extra banks cannot create transfer bandwidth.

**What happens when compute is slower?** Two banks usually provide enough
overlap. Runtime spent nearly all clocks at limit two in the stable 8/20 case.

**What happened under variable latency?** For 64 tiles, fixed four-bank took
983 cycles, runtime 1025, and ping-pong 1072. Runtime averaged 2.50 eligible
banks. The 42-cycle penalty reflects delayed depth increases and mode changes.

**What happened in the phase experiment?** Runtime started at two, reached
four during irregular transfer timing, and returned to two. It took 2033
cycles versus 1991 for fixed four-bank, averaging 2.582 banks.

**Is lower average bank count a power saving?** No. All four physical RAMs
remain instantiated; average limit measures eligible buffering depth only.
Power needs switching activity and a technology-specific power flow.

**What are utilization, throughput, and stall fraction?** MAC busy clocks
divided by total clocks; completed tiles divided by total clocks; compute
idle clocks divided by total clocks. Our stall metric includes initial fill.

**How was correctness checked?** Icarus simulated pure Verilog. The
self-checking testbench computed every expected tile MAC result independently,
checked IDs and duplicates, and stopped on mismatches. Fourteen cases passed.

**How do you know old behavior was preserved?** The 103 pre-extension runs
were archived. Seven core metrics matched exactly after the new policy was
added.

**How does the literature-inspired baseline relate to papers?** It is a
generic static cyclic multi-bank proxy under our own RAM and MAC. It is not
an exact Eyeriss, TPU, or Eyeriss v2 reproduction.

**Which prior works were studied?** Eyeriss measured local reuse and CNN
throughput; the TPU paper measured full-system inference performance; Eyeriss
v2 measured flexible sparse-model throughput. Exact numbers and DOIs are in
`previous_work_results.md`.

**Can their numbers be directly compared with ours?** No. Their workloads,
silicon, clocks, and denominators differ. The comparison is qualitative;
the controlled internal RTL comparison is direct.

**What is the strongest finding?** Stable cases matched fixed four-bank
execution time with an average limit near two. Under changing latency,
runtime used fewer eligible banks but paid 2.11–4.27% more cycles.

**Where does the design not help?** It does not beat fixed four-bank timing in
the measured cases. Static cyclic four-bank also matched availability
scheduling under this serial source. The policy has a tradeoff rather than a
universal speedup.

**Is this physical SRAM design?** No. `sync_ram.v` is behavioral RTL with
synchronous read and write. Physical SRAM needs a macro, timing, power,
layout, and technology characterization.

**What would make it silicon-ready?** A specified memory macro and timing
interface, synthesis and place-and-route, clock/reset constraints, real
external-memory interface, power analysis, and broader workload traces.
